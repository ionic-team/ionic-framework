import type { Components, JSX } from "../dist/types/interface";

interface IonPopover extends Components.IonPopover, HTMLElement {}
export const IonPopover: {
  prototype: IonPopover;
  new (): IonPopover;
};
