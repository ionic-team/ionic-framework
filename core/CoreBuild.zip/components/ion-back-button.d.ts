import type { Components, JSX } from "../dist/types/interface";

interface IonBackButton extends Components.IonBackButton, HTMLElement {}
export const IonBackButton: {
  prototype: IonBackButton;
  new (): IonBackButton;
};
