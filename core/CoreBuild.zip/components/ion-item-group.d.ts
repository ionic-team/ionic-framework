import type { Components, JSX } from "../dist/types/interface";

interface IonItemGroup extends Components.IonItemGroup, HTMLElement {}
export const IonItemGroup: {
  prototype: IonItemGroup;
  new (): IonItemGroup;
};
