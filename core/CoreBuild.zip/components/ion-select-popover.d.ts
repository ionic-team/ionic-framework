import type { Components, JSX } from "../dist/types/interface";

interface IonSelectPopover extends Components.IonSelectPopover, HTMLElement {}
export const IonSelectPopover: {
  prototype: IonSelectPopover;
  new (): IonSelectPopover;
};
