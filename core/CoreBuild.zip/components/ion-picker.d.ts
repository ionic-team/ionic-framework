import type { Components, JSX } from "../dist/types/interface";

interface IonPicker extends Components.IonPicker, HTMLElement {}
export const IonPicker: {
  prototype: IonPicker;
  new (): IonPicker;
};
