import type { Components, JSX } from "../dist/types/interface";

interface IonChip extends Components.IonChip, HTMLElement {}
export const IonChip: {
  prototype: IonChip;
  new (): IonChip;
};
