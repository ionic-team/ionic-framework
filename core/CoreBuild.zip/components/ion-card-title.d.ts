import type { Components, JSX } from "../dist/types/interface";

interface IonCardTitle extends Components.IonCardTitle, HTMLElement {}
export const IonCardTitle: {
  prototype: IonCardTitle;
  new (): IonCardTitle;
};
