import type { Components, JSX } from "../dist/types/interface";

interface IonText extends Components.IonText, HTMLElement {}
export const IonText: {
  prototype: IonText;
  new (): IonText;
};
