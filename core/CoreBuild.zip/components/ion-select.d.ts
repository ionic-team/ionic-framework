import type { Components, JSX } from "../dist/types/interface";

interface IonSelect extends Components.IonSelect, HTMLElement {}
export const IonSelect: {
  prototype: IonSelect;
  new (): IonSelect;
};
