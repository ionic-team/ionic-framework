import type { Components, JSX } from "../dist/types/interface";

interface IonReorderGroup extends Components.IonReorderGroup, HTMLElement {}
export const IonReorderGroup: {
  prototype: IonReorderGroup;
  new (): IonReorderGroup;
};
