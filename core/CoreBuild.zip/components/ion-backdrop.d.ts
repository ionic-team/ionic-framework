import type { Components, JSX } from "../dist/types/interface";

interface IonBackdrop extends Components.IonBackdrop, HTMLElement {}
export const IonBackdrop: {
  prototype: IonBackdrop;
  new (): IonBackdrop;
};
