import type { Components, JSX } from "../dist/types/interface";

interface IonCardHeader extends Components.IonCardHeader, HTMLElement {}
export const IonCardHeader: {
  prototype: IonCardHeader;
  new (): IonCardHeader;
};
