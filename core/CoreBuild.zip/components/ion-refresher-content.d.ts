import type { Components, JSX } from "../dist/types/interface";

interface IonRefresherContent extends Components.IonRefresherContent, HTMLElement {}
export const IonRefresherContent: {
  prototype: IonRefresherContent;
  new (): IonRefresherContent;
};
