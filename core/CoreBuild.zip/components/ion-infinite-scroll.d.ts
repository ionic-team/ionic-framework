import type { Components, JSX } from "../dist/types/interface";

interface IonInfiniteScroll extends Components.IonInfiniteScroll, HTMLElement {}
export const IonInfiniteScroll: {
  prototype: IonInfiniteScroll;
  new (): IonInfiniteScroll;
};
