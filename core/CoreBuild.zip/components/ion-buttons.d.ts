import type { Components, JSX } from "../dist/types/interface";

interface IonButtons extends Components.IonButtons, HTMLElement {}
export const IonButtons: {
  prototype: IonButtons;
  new (): IonButtons;
};
