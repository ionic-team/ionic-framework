import type { Components, JSX } from "../dist/types/interface";

interface IonCardSubtitle extends Components.IonCardSubtitle, HTMLElement {}
export const IonCardSubtitle: {
  prototype: IonCardSubtitle;
  new (): IonCardSubtitle;
};
