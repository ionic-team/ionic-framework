import type { Components, JSX } from "../dist/types/interface";

interface IonDatetime extends Components.IonDatetime, HTMLElement {}
export const IonDatetime: {
  prototype: IonDatetime;
  new (): IonDatetime;
};
