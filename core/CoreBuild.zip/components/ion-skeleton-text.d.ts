import type { Components, JSX } from "../dist/types/interface";

interface IonSkeletonText extends Components.IonSkeletonText, HTMLElement {}
export const IonSkeletonText: {
  prototype: IonSkeletonText;
  new (): IonSkeletonText;
};
