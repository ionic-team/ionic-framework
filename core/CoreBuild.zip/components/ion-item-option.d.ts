import type { Components, JSX } from "../dist/types/interface";

interface IonItemOption extends Components.IonItemOption, HTMLElement {}
export const IonItemOption: {
  prototype: IonItemOption;
  new (): IonItemOption;
};
