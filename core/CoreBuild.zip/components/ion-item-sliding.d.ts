import type { Components, JSX } from "../dist/types/interface";

interface IonItemSliding extends Components.IonItemSliding, HTMLElement {}
export const IonItemSliding: {
  prototype: IonItemSliding;
  new (): IonItemSliding;
};
