import type { Components, JSX } from "../dist/types/interface";

interface IonLoading extends Components.IonLoading, HTMLElement {}
export const IonLoading: {
  prototype: IonLoading;
  new (): IonLoading;
};
