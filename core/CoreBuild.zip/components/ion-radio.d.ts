import type { Components, JSX } from "../dist/types/interface";

interface IonRadio extends Components.IonRadio, HTMLElement {}
export const IonRadio: {
  prototype: IonRadio;
  new (): IonRadio;
};
