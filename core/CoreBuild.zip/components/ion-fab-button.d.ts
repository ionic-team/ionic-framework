import type { Components, JSX } from "../dist/types/interface";

interface IonFabButton extends Components.IonFabButton, HTMLElement {}
export const IonFabButton: {
  prototype: IonFabButton;
  new (): IonFabButton;
};
