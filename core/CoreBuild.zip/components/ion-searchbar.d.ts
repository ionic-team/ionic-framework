import type { Components, JSX } from "../dist/types/interface";

interface IonSearchbar extends Components.IonSearchbar, HTMLElement {}
export const IonSearchbar: {
  prototype: IonSearchbar;
  new (): IonSearchbar;
};
