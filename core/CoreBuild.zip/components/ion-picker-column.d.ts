import type { Components, JSX } from "../dist/types/interface";

interface IonPickerColumn extends Components.IonPickerColumn, HTMLElement {}
export const IonPickerColumn: {
  prototype: IonPickerColumn;
  new (): IonPickerColumn;
};
