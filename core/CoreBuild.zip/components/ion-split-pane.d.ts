import type { Components, JSX } from "../dist/types/interface";

interface IonSplitPane extends Components.IonSplitPane, HTMLElement {}
export const IonSplitPane: {
  prototype: IonSplitPane;
  new (): IonSplitPane;
};
