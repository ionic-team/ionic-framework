import type { Components, JSX } from "../dist/types/interface";

interface IonReorder extends Components.IonReorder, HTMLElement {}
export const IonReorder: {
  prototype: IonReorder;
  new (): IonReorder;
};
