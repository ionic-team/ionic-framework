import type { Components, JSX } from "../dist/types/interface";

interface IonFabList extends Components.IonFabList, HTMLElement {}
export const IonFabList: {
  prototype: IonFabList;
  new (): IonFabList;
};
