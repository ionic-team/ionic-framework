import type { Components, JSX } from "../dist/types/interface";

interface IonRadioGroup extends Components.IonRadioGroup, HTMLElement {}
export const IonRadioGroup: {
  prototype: IonRadioGroup;
  new (): IonRadioGroup;
};
