import type { Components, JSX } from "../dist/types/interface";

interface IonListHeader extends Components.IonListHeader, HTMLElement {}
export const IonListHeader: {
  prototype: IonListHeader;
  new (): IonListHeader;
};
