import type { Components, JSX } from "../dist/types/interface";

interface IonRow extends Components.IonRow, HTMLElement {}
export const IonRow: {
  prototype: IonRow;
  new (): IonRow;
};
