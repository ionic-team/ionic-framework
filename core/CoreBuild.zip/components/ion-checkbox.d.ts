import type { Components, JSX } from "../dist/types/interface";

interface IonCheckbox extends Components.IonCheckbox, HTMLElement {}
export const IonCheckbox: {
  prototype: IonCheckbox;
  new (): IonCheckbox;
};
