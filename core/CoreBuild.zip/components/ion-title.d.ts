import type { Components, JSX } from "../dist/types/interface";

interface IonTitle extends Components.IonTitle, HTMLElement {}
export const IonTitle: {
  prototype: IonTitle;
  new (): IonTitle;
};
